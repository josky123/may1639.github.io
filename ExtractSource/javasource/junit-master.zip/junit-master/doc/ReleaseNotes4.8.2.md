## Summary of Changes in version 4.8.2 ##

This was a quick bugfix release

### Bug fixes ###

- github#96: TestSuite(MyTestCase.class) should dynamically detect if MyTestCase
  is a TestCase
