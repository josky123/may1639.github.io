package junit.tests.framework;

import junit.framework.TestCase;

/**
 * Test class used in SuiteTest
 */
public class NoTestCases extends TestCase {
    public void noTestCase() {
    }
}