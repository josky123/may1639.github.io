/**
 * Tests the JUnit v3.x framework.
 */
package junit.tests;